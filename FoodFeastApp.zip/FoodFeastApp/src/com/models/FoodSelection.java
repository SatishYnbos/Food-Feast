package com.models;

public class FoodSelection {
	private String foodType;
	private int foodQuantity;
	public FoodSelection(String fType, int fQuantity) {
		foodType=fType;
		foodQuantity=fQuantity;
	}
	public static FoodSelection get(String foodType, int foodQuantity) {
		FoodSelection foodSelection=new FoodSelection(foodType, foodQuantity);
		return foodSelection;
	}
	public String getFoodType() {
		return foodType;
	}
	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}
	public int getFoodQuantity() {
		return foodQuantity;
	}
	public void setFoodQuantity(int foodQuantity) {
		this.foodQuantity = foodQuantity;
	}
	@Override
	public String toString() {
		return foodType + ", foodQuantity=" + foodQuantity ;
	}
	
}
