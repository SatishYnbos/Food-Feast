package com.models;

public class RestaurantSelection {
	private Restaurant selectedRestaurant;
	public RestaurantSelection(Restaurant sRestaurant) {
		selectedRestaurant=sRestaurant;
	}
	public static RestaurantSelection get(Restaurant selectedRestaurant) {
		RestaurantSelection restaurantSelection=new RestaurantSelection(selectedRestaurant);
		return restaurantSelection;
	}
	public Restaurant getSelectedRestaurant() {
		return selectedRestaurant;
	}
	public void setSelectedRestaurant(Restaurant selectedRestaurant) {
		this.selectedRestaurant = selectedRestaurant;
	}
	@Override
	public String toString() {
		return selectedRestaurant + "";
	}
}
