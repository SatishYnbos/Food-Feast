package com.models.testclasses;

import static org.junit.Assert.*;

import org.junit.Test;

import com.listtypeservices.SelectionList;
import com.models.Customer;
import com.models.Location;
import com.models.Order;

public class CustomerTest {
	@Test
	public void testSetterAndGetterForCustomerName() {
		String someName="satish";
		Customer customer=new Customer();
		customer.setCustomerName(someName);
		assertEquals(customer.getCustomerName(),someName);
	}
	@Test		
	public void testSetterAndGetterForMobileNo() {
		String someNo="9490151355";
		Customer customer=new Customer();
		customer.setMobileNo(someNo);
		assertEquals(customer.getMobileNo(), someNo);
	}
	@Test
	public void testSetterAndGetterForAddress() {
		String someAddr="hyd";
		Customer customer=new Customer();
		customer.setAddress(someAddr);
		assertEquals(customer.getAddress(), someAddr);
	}
	@Test
	public void testSetterAndGetterForLocation() {
		Location location=new Location("hyd");
		Customer customer=new Customer();
		customer.setLocation(location);
		assertEquals(customer.getLocation(), location);
	}
	@Test
	public void testSetterAndGetterForOrder() {
		Order order=new Order(2, "satish", "9490151355");
		Customer customer=new Customer();
		customer.setCustomerOrder(order);
		assertEquals(customer.getCustomerOrder(), order);
	}
	@Test
	public void testPlaceOrder() {
		String someString="";
		Customer customer=new Customer();
		SelectionList orderWithSelectedRestaurentAndFood=null;
		String isSameString=customer.placeOrder(orderWithSelectedRestaurentAndFood);
		assertEquals(someString, isSameString);
	}
}
