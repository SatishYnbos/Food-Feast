package com.models.testclasses;

import static org.junit.Assert.*;

import org.junit.Test;

import com.listtypeservices.RestaurantList;
import com.models.Location;
import com.models.Restaurant;

public class LocationTest {
	@Test
	public void testSetterAndGetterForSelectArea() {
		String someArea="hyd";
		Location loc=new Location("hyd");
		loc.setSelectArea(someArea);
		assertEquals(loc.getSelectArea(), someArea);
	}
	@Test
	public void testSetterAndGetterForRetaurantList() {
		RestaurantList list=new RestaurantList();
		Restaurant kb=new Restaurant("kb");
		list.addRestaurant(kb);
		Location loc=new Location("hyd");
		loc.setRestaurantList(list);
		assertEquals(loc.getRestaurantList(), list);
	}
}
