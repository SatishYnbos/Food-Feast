package com.models.testclasses;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.models.Food;


public class FoodTest {
	@Test
	public void evaluatesGet() {
		Food food=new Food("biryani",200);
		food=Food.get("biryani",200);
		assertEquals(food,food);
	}
	@Test
	public void testSetterAndGetterForFoodType() {
		String someFood="hi this food type";
		Food food=new Food("biryani",200);
		food.setFoodType(someFood);
		String sameFood=food.getFoodType();
		assertEquals(someFood, sameFood);	
	}
	@Test
	public void testSetterAndGetterForFoodPrice() {
		int someFood=200;
		Food food=new Food("biryani",300);
		food.setFoodPrice(someFood);
		int sameFood=food.getFoodPrice();
		assertEquals(someFood,sameFood);
	}
}
